// This is an auto-generated file to redirect any included
// module headers to the correct external folder.

#include "../../../../JUCE/modules/juce_audio_processors/juce_audio_processors.h"
