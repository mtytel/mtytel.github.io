/*

    IMPORTANT! This file is auto-generated each time you save your
    project - if you alter its contents, your changes may be overwritten!

    This file pulls in a module's source code, and builds it using the settings
    defined in AppConfig.h.

    If you want to change the method by which Juce is linked into your app, use the
    Jucer to change it, rather than trying to edit this file directly.

*/

#include "AppConfig.h"
#include "../../../modules/juce_core/juce_core.cpp"
